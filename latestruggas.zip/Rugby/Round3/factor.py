import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#from math import pi
import textwrap

os.chdir('C:\\Users\\zw894hp\\Documents\\Rugby\\Round3\\')

team_stats = pd.read_csv('Round3_Teams_2020.csv')
ply_stats = pd.read_csv('Round3_Players_2020.csv')

tm_list = {'BLU':'Blues',
            'BRU':'Brumbies',
            'BUL':'Bulls',
            'CHI':'Chiefs',
            'CRU':'Crusaders',
            'HIG':'Highlanders',
            'HUR':'Hurricanes',
            'JAG':'Jaguares',
            'LIO':'Lions',
            'REB':'Rebels',
            'RED':'Reds',
            'SHA':'Sharks',
            'STO':'Stormers',
            'SUN':'Sunwolves',
            'WAR':'Waratahs'
            }

#TEAM STATS
stats_required = ['Match_ID','Team','Carries Metres','Runs','Lineout Throw Won Clean',
                  'Lineout Won Steal','Red Cards','Yellow Cards']

ply_to_team = ply_stats[stats_required]
ply_to_team = ply_to_team.groupby(['Match_ID','Team'],as_index=False).sum()
all_team_stats = pd.merge(team_stats,ply_to_team, on=['Team','Match_ID'])

scrums = all_team_stats[['Team','Scrums won','Scrums lost']]

def getave(x):
    if type(x) == int:
        return round(x/23,2)
    else:
        return x

teams_ave = all_team_stats.applymap(getave)

teams_ave['Carry Metres'] = teams_ave['Carries Metres'] 
teams_ave['Linebreaks'] = teams_ave['Defenders beaten'] + teams_ave['Clean breaks']
teams_ave['Passing'] = teams_ave['Passes'] + teams_ave['Offloads']
teams_ave['Missed Tackles'] = - teams_ave['Missed tackles']
teams_ave['Turnovers Conceded'] = - teams_ave['Turnovers conceded']
#teams_ave['Lineouts'] = teams_ave['Lineout Throw Won Clean'] + teams_ave['Lineout Won Steal'] - teams_ave['Lineouts lost']
teams_ave['Penalties Conceded'] = - teams_ave['Penalties conceded']
teams_ave['Cards'] = - teams_ave['Red Cards'] - teams_ave['Yellow Cards']
teams_ave['Set Piece'] = teams_ave['Scrums won'] - teams_ave['Scrums lost'] + teams_ave['Lineout Throw Won Clean'] + teams_ave['Lineout Won Steal'] - teams_ave['Lineouts lost']
teams_ave['Goal Kicking'] = teams_ave['Penalty goals'] + teams_ave['Drop goals'] + teams_ave['Conversions']
teams_ave['Turnovers Won'] = teams_ave['Turnovers won']
teams_ave['Kicks'] = teams_ave['Kicks in play']
teams_ave = teams_ave.drop(columns=['Match_ID','Territory','Defenders beaten','Clean breaks','Rucks won %',
                                    'Passes','Offloads','Lineouts lost','Mauls won','Scrums won %',
                                    'Lineout Won Steal','Lineout Throw Won Clean','Red Cards','Yellow Cards','Possession',
                                    'Scrums won','Scrums lost','Rucks won', 'Rucks lost','Carries Metres',
                                    'Missed tackles','Turnovers conceded','Penalties conceded',
                                    'Scrums won','Scrums lost','Conversions missed','Penalty goals missed','Drop goals missed',
                                    'Penalty goals','Drop goals','Conversions','Turnovers won','Kicks in play','Score'])


#Players
ply_stats['Scrums won'] = 0
ply_stats['Scrums lost'] = 0

p_stats = ['Player','Team','Number',
           'Tries','Carries Metres','Runs','Defenders Beaten','Clean Breaks','Passes','Offload','Turnovers Conceded',
           'Points','Tackles','Missed Tackles','Turnover Won','Kicks From Hand','Conversion Goals','Penalty Goals','Drop Goals Converted',
           'Lineout Throw Won Clean','Lineout Won Steal','Penalties Conceded','Red Cards','Yellow Cards',
           'Scrums won','Scrums lost']

players = ply_stats[p_stats]

#GET SCRUMS?
def get_scrums_w(row):
    y = row['Number']
    x = scrums['Scrums won'][scrums['Team'] == row['Team']].iloc[0]
    if y in [1,2,3,16,17,18]:
        return x
    else:
        return 0

def get_scrums_l(row):
    y = row['Number']
    x = scrums['Scrums lost'][scrums['Team'] == row['Team']].iloc[0]
    if y in [1,2,3,16,17,18]:
        return 0 - x
    else:
        return 0  


players['Scrums won'] = players.apply(get_scrums_w, axis=1)
players['Scrums lost'] = players.apply(get_scrums_l, axis=1)

players['Carry Metres'] = players['Carries Metres'] 
players['Linebreaks'] = players['Defenders Beaten'] + players['Clean Breaks']
players['Passing'] = players['Passes'] + players['Offload']
players['Missed Tackles'] = - players['Missed Tackles']
players['Turnovers Conceded'] = - players['Turnovers Conceded']
#players['Lineouts'] = players['Lineout Throw Won Clean'] + players['Lineout Won Steal'] #- players['Lineouts lost']
players['Penalties Conceded'] = - players['Penalties Conceded']
players['Cards'] = - players['Red Cards'] - players['Yellow Cards'] 
players['Set Piece'] = players['Scrums won'] - players['Scrums lost'] + players['Lineout Throw Won Clean'] + players['Lineout Won Steal']
players['Goal Kicking'] = players['Penalty Goals'] + players['Drop Goals Converted'] + players['Conversion Goals']
players['Kicks'] = players['Kicks From Hand']
players['Turnovers Won'] = players['Turnover Won']

players = players.drop(columns=['Carries Metres','Defenders Beaten','Clean Breaks','Passes','Offload',
                                'Lineout Throw Won Clean','Lineout Won Steal','Red Cards','Yellow Cards',
                                'Scrums won','Scrums lost','Penalty Goals','Drop Goals Converted','Conversion Goals'
                                ,'Kicks From Hand','Points','Turnover Won'])

    
teams_ave = teams_ave[['Team','Tries','Runs','Carry Metres','Linebreaks','Passing','Kicks','Tackles','Missed Tackles', 
                        'Turnovers Won','Turnovers Conceded','Penalties Conceded','Goal Kicking','Set Piece','Cards',]]   
 
players = players[['Player','Number','Team','Tries','Runs','Carry Metres','Linebreaks','Passing','Kicks','Tackles','Missed Tackles', 
                    'Turnovers Won','Turnovers Conceded','Penalties Conceded','Goal Kicking','Set Piece','Cards',]]



teams_ave['Carry Metres'] = teams_ave['Carry Metres'].apply(lambda x : round(x / 10,2))
teams_ave['Passing'] = teams_ave['Passing'].apply(lambda x : round(x / 10,2))
teams_ave['Kicks'] = teams_ave['Kicks'].apply(lambda x : round(x / 5,2)) 

players['Carry Metres'] = players['Carry Metres'].apply(lambda x : round(x / 10,2))
players['Passing'] = players['Passing'].apply(lambda x : round(x / 10,2))
players['Kicks'] = players['Kicks'].apply(lambda x : round(x / 5,2)) 




def pos_stats(x,z):
    if x > 0:
        if x - z < 0:
            x = 0
        else:
            x = round(x - z,2)
    else:
        x = 0
    return x

def neg_stats(x,z):
    if x < 0:
        if x - z > 0:
            x = 0
        else:
            x = round(x - z,2)
    else:
        x = 0
    return x


final_plys = pd.DataFrame(columns = players.columns)

for x, pstats in players.iterrows():
    team = pstats['Team']
    ply = pstats['Player']
    array1 = players[(players['Team'] == team) & (players['Player'] == ply)].values[0]
    array2 = teams_ave[teams_ave['Team'] == team].values[0]
    for y in range(3,len(array1)): 
        t_stat = array2[y-2]   
        if y in (10,12,13):
            array1[y] = neg_stats(array1[y],t_stat) 
        else:
            array1[y] = pos_stats(array1[y],t_stat) 
    
    final_plys.loc[len(final_plys)] = array1

final_plys['Total'] = final_plys.iloc[:,-14:].sum(axis = 1)



#Getting Plots
final_plys.sort_values(by = 'Total', inplace = True, ascending = False)
top_players = final_plys.head(20)



#Plotting
all_bars = ('Tries', 'Runs', 'Carry Metres', 'Linebreaks', 'Passing', 'Kicks', 'Tackles', 
        'Missed Tackles','Turnovers Won', 'Turnovers Conceded', 'Penalties Conceded',
        'Goal Kicking','Set Piece',	'Cards') 



for x, grp in top_players.iterrows():
    
    test_team = teams_ave[teams_ave['Team'] == grp['Team']]  
    stg_height = grp[3:17].values
    height = []
    elements = []
    e = 0
    cm = []
    for i in stg_height:      
        if i != 0:
            height.append(i)
            elements.append(e)
            if i > 0:
                cm.append('b')
            else:
                cm.append('r')
        e += 1
    
   
    tave_stg = test_team.iloc[:,1:15].values[0]
    tave = []
    bars = []
    for z in elements:   
        bars.append(all_bars[z])
        tave.append(tave_stg[z])
   
    
    y_pos = np.arange(len(bars))        
    fig, ax = plt.subplots()
    ax.grid(linestyle = ':', axis = 'y')
    
    plt.bar(y_pos, height, color = cm)
    #plt.xticks(y_pos, bars, rotation = 90)
    plt.xticks(y_pos, [textwrap.fill(label, 10) for label in bars], rotation = 90)
    
    plt.ylabel('Impact Score')
    plt.plot(tave, color  = 'grey')
    title = grp[0] + ' - ' + tm_list[grp[2]]
    save_string = grp[0] + '_' + tm_list[grp[2]]
    plt.title(title)
    plt.legend(['Team Ave'])
    plt.savefig(save_string, bbox_inches='tight')
    plt.show()
