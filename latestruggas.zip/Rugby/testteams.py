import requests
from bs4 import BeautifulSoup
import pandas as pd
import os
import time
    
#Get all links for 2019
os.chdir('C:\\Users\\zw894hp\\Documents\Rugby\\')
full_matches = pd.read_csv('Links_2019.csv')
matches = full_matches['URL'].loc[full_matches['Status'] != 'No Stats']

#url = matches[0]
#url2 = matches[71]
for url in matches:
    match_id = url[43:-12].replace('-vs','').replace('-at','').replace('-on','')
    time.sleep(2)
    page = requests.get(url)
    soup = BeautifulSoup(page.content,'html.parser')   
    
    tables = soup.find_all('table')
    home = soup.find('div', class_='team-abrev home').text
    away = soup.find('div', class_='team-abrev away').text
    home_score = soup.find('div', class_='home team-home-score').text.strip()
    away_score = soup.find('div', class_='away team-away-score').text.strip()

    #Team Stats 
    t_headings = ['Team','Score']
    t_home =[home,home_score]
    t_away = [away,away_score]
    
    for x in soup.find_all('div', class_='titles'):
        for y in x:
            if y != ' ':
                if str(y.get('class')).replace('[','').replace(']','').replace("'",'').replace("'",'') == 'label':
                    t_headings.append(y.text)
                if str(y.get('class')).replace('[','').replace(']','').replace("'",'').replace("'",'') == 'home':
                    t_home.append(y.text)
                if str(y.get('class')).replace('[','').replace(']','').replace("'",'').replace("'",'') == 'away':
                    t_away.append(y.text)               
    t_stg = [t_home]
    t_stg.append(t_away)
    team_stg = pd.DataFrame(t_stg, columns = t_headings)
    
    check_list = ['Possession','Tries','Passes','Tackles','Kicks in play','Conversions','Rucks won','Rucks lost']
    pie_headers = ['Team']
    for i in soup.find_all('div', class_= 'key-stats-group-graph'):
        headers = i.text.split(',')
        for item in headers:
            string_check = item.replace('"','')
            if string_check in check_list:
                pie_headers.append(string_check)
    
    #Get the team stats from the pie graphs used
    pie_stats = []
    pie_home = [home]
    pie_away = [away]
    counter = 0
    
    for i in soup.find_all('div', class_= 'key-stats-group-graph'):
        if i.text.find('Drop') == -1:
            headers = i.text.split(',')
            for items in headers:
                if items.find('"') == -1:
                    if items.find(';') == -1:
                        counter += 1
                        if (counter % 2) == 0:
                            pie_home.append(items)
                        else:
                            pie_away.append(items)
    pie_stats.append(pie_home)
    pie_stats.append(pie_away)
    #pie_stats
    
    #Convert pie graph stats into dataframe
    teams_pies = pd.DataFrame(pie_stats)
    teams_pies.columns = pie_headers
    
    team_stats_stg = pd.merge(team_stg,teams_pies,on='Team')
    team_stats_stg['Match_ID'] = match_id
    
    if 'team_stats_final' not in locals():
        team_stats_final = team_stats_stg
    else:
        team_stats_final = team_stats_final.append(team_stats_stg, sort = False)

team_stats_final.to_csv('Team_Stats_2019_updated.csv',index=False)


