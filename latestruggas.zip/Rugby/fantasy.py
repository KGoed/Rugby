import pandas as pd
import os
import math


os.chdir('C:\\Users\\zw894hp\\Documents\Rugby\\')

points_system = pd.read_csv('PointsSystem.csv')
players_stats = pd.read_csv('Player_Stats_2019_Cleaned.csv')
team_stats = pd.read_csv('Team_Stats_2019.csv')



fr = [1,2,3]
lks = [4,5]
front_row = players_stats[players_stats['Number'].isin(fr)]['Player']
front_row = front_row.values.tolist()
locks = players_stats[players_stats['Number'].isin(lks)]['Player']
locks = locks.values.tolist()

players_stats['Kicker'] = players_stats['Conversion Goals'] + players_stats['Penalty Goals']

team_stats['Missed Kick'] = team_stats['Conversions missed'] + team_stats['Penalty goals missed'] + team_stats['Drop goals missed']

players_stats['Games'] = 1
team_stats['Games'] = 1

full_team_stats = team_stats.drop(['Score','Metres carried','Carries','Defenders beaten','Clean breaks','Offloads',
'Turnovers conceded','Missed tackles','Turnovers won','Penalty goals','Drop goals','Rucks won %','Mauls won',
'Lineouts won','Lineouts won %','Scrums lost','Scrums won %','Penalties conceded','Red cards','Yellow cards',
'Possession','Tries','Passes','Tackles','Kicks in play','Conversions','Rucks won','Rucks lost','Match_ID',
'Conversions missed','Penalty goals missed','Drop goals missed'], axis = 1)
full_team_stats = full_team_stats.groupby('Team',as_index=False).sum()

full_team_stats['Missed Kick'] = full_team_stats['Missed Kick'].apply(lambda x: x * -2)
full_team_stats['Lineouts lost'] = full_team_stats['Lineouts lost'].apply(lambda x: x * -2)

full_player_stats = players_stats.drop(['Number','Venue','Match_ID','Runs','Passes','Lineout Throw Won Clean',
                                        'Points'], axis = 1)
full_player_stats = full_player_stats.groupby(['Player','Team'],as_index=False).sum()
full_player_stats['Tries'] = full_player_stats['Tries'].apply(lambda x: x * 12)
full_player_stats['Try Assist'] = full_player_stats['Try Assist'].apply(lambda x: x * 6)
full_player_stats['Conversion Goals'] = full_player_stats['Conversion Goals'].apply(lambda x: x * 4)
full_player_stats['Penalty Goals'] = full_player_stats['Penalty Goals'].apply(lambda x: x * 6)
full_player_stats['Drop Goals Converted'] = full_player_stats['Drop Goals Converted'].apply(lambda x: x * 6)
full_player_stats['Tackles'] = full_player_stats['Tackles'].apply(lambda x: math.floor(x/2) * 2)
full_player_stats['Defenders Beaten'] = full_player_stats['Defenders Beaten'].apply(lambda x: x * 2)
full_player_stats['Missed Tackles'] = full_player_stats['Missed Tackles'].apply(lambda x: x * -2)
full_player_stats['Clean Breaks'] = full_player_stats['Clean Breaks'].apply(lambda x: x * 6)
full_player_stats['Offload'] = full_player_stats['Offload'].apply(lambda x: x * 2)
full_player_stats['Lineouts Won'] = full_player_stats['Lineouts Won'].apply(lambda x: x * 2)
full_player_stats['Lineout Won Steal'] = full_player_stats['Lineout Won Steal'].apply(lambda x: x * 4)
full_player_stats['Kicks From Hand'] = full_player_stats['Kicks From Hand'].apply(lambda x: math.floor(x/4) * 2)
full_player_stats['Carries Metres'] = full_player_stats['Carries Metres'].apply(lambda x: math.floor(x/10 * 2))
full_player_stats['Turnovers Conceded'] = full_player_stats['Turnovers Conceded'].apply(lambda x: x * -2)
full_player_stats['Turnover Won'] = full_player_stats['Turnover Won'].apply(lambda x: x * 2)
full_player_stats['Penalties Conceded'] = full_player_stats['Penalties Conceded'].apply(lambda x: x * -2)
full_player_stats['Yellow Cards'] = full_player_stats['Yellow Cards'].apply(lambda x: x * -6)
full_player_stats['Red Cards'] = full_player_stats['Red Cards'].apply(lambda x: x * -12)

for col in full_player_stats.columns:
    if col not in ['Team','Player','Kicker','Games']:
        full_player_stats[col] = round(full_player_stats[col] / full_player_stats['Games'],2)

for col in full_team_stats.columns:
    if col not in ['Team','Games']:
        full_team_stats[col] = round(full_team_stats[col] / full_team_stats['Games'],2)

full_player_stats = full_player_stats.drop(['Games'], axis = 1)
full_team_stats = full_team_stats.drop(['Games'], axis = 1)

final_stats = pd.merge(full_player_stats,full_team_stats, how = 'inner', on = 'Team')

def kicking(kick, pts):
    x = 0
    if kick > 0:
        x = pts
    return x


final_stats['Missed Kick'] = final_stats.apply(lambda x: kicking(x['Kicker'], x['Missed Kick']), axis=1)

def fronts(fply, pts):
    x = 0
    if fply in front_row:
        x = pts
    return x

final_stats['Scrums won'] = final_stats.apply(lambda x: fronts(x['Player'], x['Scrums won']), axis=1)

def lines(lply, pts):
    x = 0
    if lply in locks:
        x = pts
    return x

final_stats['Lineouts lost'] = final_stats.apply(lambda x: fronts(x['Player'], x['Lineouts lost']), axis=1)


final_stats['Total Points'] = final_stats['Tries'] + final_stats['Carries Metres'] + final_stats['Defenders Beaten'] + final_stats['Clean Breaks'] + final_stats['Offload'] + final_stats['Turnovers Conceded'] + final_stats['Try Assist'] + final_stats['Tackles'] + final_stats['Missed Tackles'] + final_stats['Turnover Won'] + final_stats['Kicks From Hand'] + final_stats['Conversion Goals'] + final_stats['Penalty Goals'] + final_stats['Drop Goals Converted'] + final_stats['Lineouts Won'] + final_stats['Lineout Won Steal'] + final_stats['Penalties Conceded'] + final_stats['Red Cards'] + final_stats['Yellow Cards'] + final_stats['Lineouts lost'] + final_stats['Scrums won'] + final_stats['Missed Kick']

export_players = players_stats[['Number','Player']]
export_players.to_csv('plys.csv',index=False)

final_stats.to_csv('fsstatsq.csv',index=False)
