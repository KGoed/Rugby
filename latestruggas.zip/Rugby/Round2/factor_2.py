import os
import pandas as pd
import numpy as np
#import matplotlib.pyplot as plt
#from math import pi
#import textwrap

os.chdir('C:\\Users\\zw894hp\\Documents\\Rugby\\Round2\\')

team_stats = pd.read_csv('Round2_Teams_2020.csv')
ply_stats = pd.read_csv('Round2_Players_2020.csv')


#TEAM STATS
stats_required = ['Match_ID','Team','Carry Metres','Runs','Lineout Throw Won',
                  'Lineout Steal','Red Cards','Yellow Cards']

ply_to_team = ply_stats[stats_required]
ply_to_team = ply_to_team.groupby(['Match_ID','Team'],as_index=False).sum()
all_team_stats = pd.merge(team_stats,ply_to_team, on=['Team','Match_ID'])

scrums = all_team_stats[['Team','Scrums won','Scrums lost']]

def getave(x):
    if type(x) == int:
        return round(x/23,2)
    else:
        return x

teams_ave = all_team_stats.applymap(getave)

teams_ave['Linebreaks'] = teams_ave['Defenders Beaten'] + teams_ave['Clean Breaks']
teams_ave['Passing'] = teams_ave['Passes'] + teams_ave['Offloads']
teams_ave['Missed Tackles'] = - teams_ave['Missed Tackles']
teams_ave['Turnovers Conceded'] = - teams_ave['Turnovers Conceded']
teams_ave['Lineouts'] = - teams_ave['Lineouts lost']
teams_ave['Penalties Conceded'] = - teams_ave['Penalties Conceded']
teams_ave['Cards '] = - teams_ave['Red Cards'] - teams_ave['Yellow Cards']
teams_ave['Scrums'] = teams_ave['Scrums won'] + teams_ave['Scrums lost']


teams_ave = teams_ave.drop(columns=['Match_ID','Territory','Defenders Beaten','Clean Breaks','Rucks won %',
                                    'Passes','Offloads','Lineouts lost','Mauls won','Scrums won %',
                                    'Lineout Steal','Red Cards','Yellow Cards','Possession',
                                    'Scrums won','Scrums lost','Rucks won', 'Rucks lost'])


#Players
ply_stats['Scrums won'] = 0
ply_stats['Scrums lost'] = 0

p_stats = ['Player','Team','Number',
           'Tries','Carry Metres','Runs','Defenders Beaten','Clean Breaks','Passes','Offloads','Turnovers Conceded',
           'Points','Tackles','Missed Tackles','Turnovers Won','Kicks','Conversions','Penalty Goals','Drop Goals',
           'Lineout Throw Won','Lineout Steal','Penalties Conceded','Red Cards','Yellow Cards',
           'Scrums won','Scrums lost']

players = ply_stats[p_stats]

players['Turnovers Conceded'] = players['Turnovers Conceded'].apply(lambda x :  0 - x)
players['Missed Tackles'] = players['Missed Tackles'].apply(lambda x :  0 - x)
players['Penalties Conceded'] = players['Penalties Conceded'].apply(lambda x :  0 - x)
players['Red Cards'] = players['Red Cards'].apply(lambda x :  0 - x)
players['Yellow Cards'] = players['Yellow Cards'].apply(lambda x :  0 - x)

scrums['Total'] = scrums['Scrums won'] + scrums['Scrums lost']
scrums['Impact'] = scrums['Scrums won'] / scrums['Total']


def get_scrums_w(row):
    y = row['Number']
    x = scrums['Scrums won'][scrums['Team'] == row['Team']].iloc[0]
    if y in [1,2,3,16,17,18]:
        return x
    else:
        return 0
    
def get_scrums_l(row):
    y = row['Number']
    x = scrums['Scrums lost'][scrums['Team'] == row['Team']].iloc[0]
    if y in [1,2,3,16,17,18]:
        return 0 - x
    else:
        return 0  
    

players['Scrums won'] = players.apply(get_scrums_w, axis=1)
players['Scrums lost'] = players.apply(get_scrums_l, axis=1)






final_plys = pd.DataFrame(columns = p_stats)




















for x, pstats in players.iterrows():
    team = pstats['Team']
    array1 = pstats.values
    array2 = teams[teams['Team'] == team].values[0]
    for y in range(3,len(array1)):
        if array2[y-2] != 0:
            array1[y] = round(array1[y] / array2[y-2] * 100, 2)
            
   
    final_plys.loc[len(final_plys)] = array1


#FIX LINEOUTS!!!!

