import requests
from bs4 import BeautifulSoup
import pandas as pd
import os


os.chdir('C:\\Users\\zw894hp\\Documents\\Rugby\\Round1\\')

headers = {
     'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
     }

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.76 Safari/537.36', "Upgrade-Insecure-Requests": "1","DNT": "1","Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language": "en-US,en;q=0.5","Accept-Encoding": "gzip, deflate"
    }

#Get all links for 2019 from csv file
link_url = 'https://www.rugbypass.com/super-rugby/matches/2020'
link_page = requests.get(link_url, headers = headers)

data=requests.get("https://www.accuweather.com/he/il/tel-aviv/215854/weather-forecast/215854", headers=headers)
link_soup = BeautifulSoup(link_page.content,'html.parser')
links = []
for item in link_soup.find_all('a',href = True):
    if item.text == 'Match Centre': 
        links.append(item['href'] + '/stats/')
links.pop(0)
links.pop()
#links

for item in link_soup.find_all('a',class_='link-box',href = True):
    links.append(item['href'] + '/stats/')

output = []   
for i in links:
    stg = []
    stg.append(i[43:-12].replace('-vs','').replace('-at','').replace('-on',''))
    stg.append(1)
    stg.append('')
    stg.append(i)
    output.append(stg)

links = pd.DataFrame(output) 
links.columns = ['Match_ID','Round','Status','URL']

links.loc[links['Match_ID'] == 'highlanders-bulls-forsyth-barr-stadium-07062019', 'Status'] = 'No Stats'
links.loc[links['Match_ID'] == 'highlanders-crusaders-forsyth-barr-stadium-16032019', 'Status'] = 'No Stats'

links.to_csv('Links_2019.csv',index=False)
