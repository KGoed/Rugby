import pandas as pd
import os
import matplotlib.pyplot as plt
from math import pi

os.chdir('C:\\Users\\zw894hp\\Documents\\Rugby\\Round1\\')

team_stats = pd.read_csv('crus_war_team.csv')
ply_stats = pd.read_csv('crus_war_plys.csv')

stats_required = team_stats.columns.tolist()

stats_required = [
'Team',
'Possession',
'Territory',
'DefBeat',
'Passes',
'Offloads',
'Tackles',
'MissedTackles',
'TurnoversCon',
'Turnovers',
'KicksinPlay%',
'Ruckswon%']

col_list = {
            'Crusaders':'darkred',
            'Waratahs':'blue'
            }

grph_stats = team_stats[stats_required]

grph_stats.rename(columns={'Ruckswon%':'Rucks Won'}, inplace=True)
grph_stats.rename(columns={'KicksinPlay%':'Kicks'}, inplace=True)
grph_stats.rename(columns={'DefBeat':'Defenders Beaten'}, inplace=True)
grph_stats.rename(columns={'TurnoversCon':'Turnovers Conceded'}, inplace=True)
grph_stats.rename(columns={'MissedTackles':'Missed Tackles'}, inplace=True)

grph_stats['Tackles'] = grph_stats['Tackles'] / 4
grph_stats['Passes'] = grph_stats['Passes'] / 4

categories=list(grph_stats)[1:]
N = len(categories)
angles = [n / float(N) * 2 * pi for n in range(N)]
angles += angles[:1]

ax = plt.subplot(111, polar=True)
ax.set_theta_offset(pi / 2)
ax.set_theta_direction(-1)
plt.xticks(angles[:-1], categories)
ax.set_rlabel_position(0)
plt.yticks([10,20,30,40,50,60], ['','','','','',''], color="grey", size=7)
plt.ylim(0,60)  

for i in range(0,len(grph_stats)):
    plyr = grph_stats.iloc[i]['Team']
    values= grph_stats.loc[i].drop('Team').values.flatten().tolist()
    values += values[:1]
    ax.plot(angles, values, linewidth=1, linestyle='solid', label=plyr, color = col_list[plyr])
    ax.fill(angles, values, 'b', alpha=0.1, color = col_list[plyr])
    plt.legend(loc='upper right', bbox_to_anchor=(0.1, 0.1))
    
#plt.savefig('graph.png', bbox_inches='tight')
plt.show()