import os
import pandas as pd
import matplotlib.pyplot as plt
import textwrap
import numpy as np

matches = (('HIG','REB'),('WAR','LIO'),('HUR','SUN'),
           ('RED','SHA'),('STO','BLU'),('BUL','JAG'))

col_list = {'BLU':'blue',
            'BRU':'gold',
            'BUL':'cornflowerblue',
            'CHI':'darkgoldenrod',
            'CRU':'darkred',
            'HIG':'green',
            #'HUR':'yellow',
            'HUR':'midnightblue',
            'JAG':'orange',
            #'LIO':'red',
            'LIO':'firebrick',
            'REB':'navy',
            'RED':'firebrick',
            'SHA':'black',
            'STO':'midnightblue',
            #'SUN':'lightsalmon',
            'SUN':'firebrick',
            #'WAR':'cyan'
            'WAR':'cornflowerblue'
            }

os.chdir(r'C:\Users\zw894hp\Documents\Rugby\Totals\\')
team_stats = pd.read_csv('Teams_2020.csv')
team_stats = team_stats.drop(columns=['Match_ID','Round'])

team_stats['Passing'] = team_stats['Passes'] + team_stats['Offloads']
team_stats['Mauls and Rucks'] = team_stats['Mauls won'] + team_stats['Rucks won']
team_stats['Set Piece'] = team_stats['Scrums won'] + team_stats['Lineout Throw Won']

def set_box_color(bp, color):
    plt.setp(bp['boxes'], color=color)
    plt.setp(bp['whiskers'], color=color)
    plt.setp(bp['caps'], color=color)
    plt.setp(bp['medians'], color=color)

dis_bels = [
        'Team',
        'Missed tackles',
        'Turnovers conceded',
        'Penalties conceded',
        'Scrums lost',
        'Rucks lost',
        'Lineouts lost'
        ]

ticks = dis_bels[1:]

att_bels = [
        'Team',
        'Runs',
        #'Carry Metres',
        'Passing',
        'Kicks in play',
        'Territory', 
        'Possession',
        'Clean breaks',
        'Defenders beaten'
        ]

ticks_a = att_bels[1:]

for x in matches:
    t1 = x[0]
    t2 = x[1]
    
    #DIS STATS
    t1_stats = team_stats[team_stats['Team'] == t1][dis_bels]
    t2_stats = team_stats[team_stats['Team'] == t2][dis_bels]
    
    data_a = [t1_stats[t1_stats.columns[1]].tolist(),
              t1_stats[t1_stats.columns[2]].tolist(), 
              t1_stats[t1_stats.columns[3]].tolist(),
              t1_stats[t1_stats.columns[4]].tolist(), 
              t1_stats[t1_stats.columns[5]].tolist(),
              t1_stats[t1_stats.columns[6]].tolist()
              ]
    data_b = [t2_stats[t2_stats.columns[1]].tolist(),
              t2_stats[t2_stats.columns[2]].tolist(), 
              t2_stats[t2_stats.columns[3]].tolist(),
              t2_stats[t2_stats.columns[4]].tolist(), 
              t2_stats[t2_stats.columns[5]].tolist(),
              t2_stats[t2_stats.columns[6]].tolist()
              ]
   
    plt.figure()
    bpl = plt.boxplot(data_a, positions=np.array(range(len(data_a)))*2.0-0.4, sym='', widths=0.6,
                      patch_artist  = True)
    bpr = plt.boxplot(data_b, positions=np.array(range(len(data_b)))*2.0+0.4, sym='', widths=0.6,
                      patch_artist  = True)
    
    set_box_color(bpl, col_list[t1]) 
    set_box_color(bpr, col_list[t2])
    
    plt.plot([], c=col_list[t1], label=t1)
    plt.plot([], c=col_list[t2], label=t2)
    plt.title('Discipline')
    plt.legend()
    
    mx_stat = 0
    for i in data_a:
        for x in i:
            if x > mx_stat:
                mx_stat = x
    for i in data_b:
        for x in i:
            if x > mx_stat:
                mx_stat = x
    
    plt.xticks(range(0, len(ticks) * 2, 2), [textwrap.fill(label, 10) for label in ticks])
    plt.xlim(-1, len(ticks)*2-1)
    plt.ylim(-1, mx_stat+2)  
    plt.tight_layout()
    g_name = t1 + '_' + t2 + '_ATT'
    plt.savefig(g_name, bbox_inches='tight')
    plt.show()
  
    #att STATS
    t1_stats = team_stats[team_stats['Team'] == t1][att_bels]
    t2_stats = team_stats[team_stats['Team'] == t2][att_bels]
    
    data_a = [t1_stats[t1_stats.columns[1]].tolist(),
              t1_stats[t1_stats.columns[2]].tolist(), 
              t1_stats[t1_stats.columns[3]].tolist(),
              t1_stats[t1_stats.columns[4]].tolist(), 
              t1_stats[t1_stats.columns[5]].tolist(),
              t1_stats[t1_stats.columns[6]].tolist(),
              t1_stats[t1_stats.columns[7]].tolist()
              #t1_stats_a[t1_stats_a.columns[8]].tolist()
              ]
    data_b = [t2_stats[t2_stats.columns[1]].tolist(),
              t2_stats[t2_stats.columns[2]].tolist(), 
              t2_stats[t2_stats.columns[3]].tolist(),
              t2_stats[t2_stats.columns[4]].tolist(), 
              t2_stats[t2_stats.columns[5]].tolist(),
              t2_stats[t2_stats.columns[6]].tolist(),
              t1_stats[t1_stats.columns[7]].tolist()
              #t1_stats_a[t1_stats_a.columns[8]].tolist()
              ]

    plt.figure()
    bpl = plt.boxplot(data_a, positions=np.array(range(len(data_a)))*2.0-0.4, sym='', widths=0.6,
                      patch_artist  = True)
    bpr = plt.boxplot(data_b, positions=np.array(range(len(data_b)))*2.0+0.4, sym='', widths=0.6,
                      patch_artist  = True)

    set_box_color(bpl, col_list[t1]) 
    set_box_color(bpr, col_list[t2])
    
    plt.plot([], c=col_list[t1], label=t1)
    plt.plot([], c=col_list[t2], label=t2)
    plt.legend()
    
    mx_stat_a = 0
    for i in data_a:
        for x in i:
            if x > mx_stat:
                mx_stat = x
    for i in data_b:
        for x in i:
            if x > mx_stat:
                mx_stat = x
    
    plt.xticks(range(0, len(ticks_a) * 2, 2), [textwrap.fill(label, 10) for label in ticks_a])
    plt.xlim(-1, len(ticks_a)*2-1)
    plt.ylim(-1, mx_stat+2)  
    plt.tight_layout()
    plt.title('Attacking')
    g_name = t1 + '_' + t2 + '_ATT'
    plt.savefig(g_name, bbox_inches='tight')
    plt.show()
