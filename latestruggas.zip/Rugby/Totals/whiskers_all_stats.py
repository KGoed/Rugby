import os
import pandas as pd
#import numpy as np
import matplotlib.pyplot as plt
#import matplotlib as mpl
#from math import pi
import textwrap
#import seaborn as sns
#import plotly.express as px

os.chdir(r'C:\Users\zw894hp\Documents\Rugby\Totals\\')

team_stats = pd.read_csv('Teams_2020.csv')

team_stats = team_stats.drop(columns=['Match_ID','Round'])

ave_team = team_stats.groupby('Team',as_index=False).mean()


#stats =  ['Team','Territory','Runs','Offloads','Turnovers won','Turnovers conceded',
 #        'Penalties conceded','Possession','Passes','Tackles','Kicks in play']

#stats =  ['Team','Territory','Possession']


#grph_stats = ave_team[stats]

#All Teams
l_bels = ['Score',
          'Possession',
        'Territory',
        'Runs',
        'Carry Metres',
        'Defenders beaten',
        'Clean breaks',
        'Kicks in play',
        'Offloads',
        'Passes',
        'Tackles',
        'Missed tackles',
        'Turnovers won',
        'Turnovers conceded',
        'Scrums won',
        'Scrums lost',
        'Mauls won',
        'Rucks won',
        'Rucks lost',
        'Lineout Throw Won',
        'Lineout Steal',
        'Lineouts lost',
        'Penalties conceded'
        ]
fig, ax = plt.subplots()
ax.grid(linestyle = ':', axis = 'y')
plt.boxplot((
            ave_team['Score'],
            ave_team['Possession'],
            ave_team['Territory'],
            ave_team['Runs'],
            ave_team['Carry Metres'],
            ave_team['Defenders beaten'],
            ave_team['Clean breaks'],
            ave_team['Kicks in play'],
            ave_team['Offloads'],
            ave_team['Passes'],
            ave_team['Tackles'],
            ave_team['Missed tackles'],
            ave_team['Turnovers won'],
            ave_team['Turnovers conceded'],
            ave_team['Scrums won'],
            ave_team['Scrums lost'],
            ave_team['Mauls won'],
            ave_team['Rucks won'],
            ave_team['Rucks lost'],
            ave_team['Lineout Throw Won'],
            ave_team['Lineout Steal'],
            ave_team['Lineouts lost'],
            ave_team['Penalties conceded']       
            ),
            patch_artist  = True,
            labels = [textwrap.fill(label, 10) for label in l_bels]
            , widths = 0.6
            )
plt.xlabel('Team Averages')
plt.show()


#Pos and Territory
fig, ax = plt.subplots()
ax.grid(linestyle = ':', axis = 'y')
#ax.set_aspect(1)
plt.boxplot((
            ave_team['Possession'],
            ave_team['Territory']
            ),
            patch_artist  = True,
            labels = [
                    'Possession',
                    'Territory'
                    ]
            , widths = 0.7
            )
plt.xlabel('Team Averages')
plt.show()

#Attacking
fig, ax = plt.subplots()
ax.grid(linestyle = ':', axis = 'y')
l_bels = ['Runs',
          #'Carry Metres',
          'Defenders beaten',
          'Clean breaks',
          'Kicks in play',
          'Offloads',
          'Passes'
                    ]
plt.boxplot((
            ave_team['Runs'],
            #ave_team['Carry Metres'],
            ave_team['Defenders beaten'],
            ave_team['Clean breaks'],
            ave_team['Kicks in play'],
            ave_team['Offloads'],
            ave_team['Passes']  
            ),
            patch_artist  = True,
            labels = [textwrap.fill(label, 10) for label in l_bels]
            )
plt.xlabel('Team Averages')
plt.show()


#Defence
fig, ax = plt.subplots()
ax.grid(linestyle = ':', axis = 'y')
l_bels = [
        'Tackles',
        'Turnovers won',
         ]
plt.boxplot((
            ave_team['Tackles'],
            ave_team['Turnovers won'],    
            ),
            patch_artist  = True,
            labels = [textwrap.fill(label, 10) for label in l_bels]
            , widths = 0.7
            )
plt.xlabel('Team Averages')
plt.show()


#Discipline
fig, ax = plt.subplots()
ax.grid(linestyle = ':', axis = 'y')
l_bels = [
        'Missed tackles',
        'Turnovers conceded',
         'Penalties conceded'
         ]
plt.boxplot((
            ave_team['Missed tackles'],
            ave_team['Turnovers conceded'],
            ave_team['Penalties conceded']       
            ),
            patch_artist  = True,
            labels = [textwrap.fill(label, 10) for label in l_bels]
            , widths = 0.7
            )
plt.xlabel('Team Averages')
plt.show()


#Set Piece
fig, ax = plt.subplots()
ax.grid(linestyle = ':', axis = 'y')
l_bels = [
        'Scrums won',
        'Scrums lost',
        'Mauls won',
        'Rucks won',
        'Rucks lost',
        'Lineout Won',
        'Lineout Steal',
        'Lineouts lost'
        ]
fig, ax = plt.subplots()
ax.grid(linestyle = ':', axis = 'y')
plt.boxplot((
            ave_team['Scrums won'],
            ave_team['Scrums lost'],
            ave_team['Mauls won'],
            ave_team['Rucks won'],
            ave_team['Rucks lost'],
            ave_team['Lineout Throw Won'],
            ave_team['Lineout Steal'],
            ave_team['Lineouts lost']     
            ),
            patch_artist  = True,
            labels = [textwrap.fill(label, 10) for label in l_bels]
            , widths = 0.7
            )
plt.xlabel('Team Averages')
plt.show()