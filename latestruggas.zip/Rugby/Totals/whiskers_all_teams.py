import os
import pandas as pd
#import numpy as np
import matplotlib.pyplot as plt
#import matplotlib as mpl
#from math import pi
import textwrap
#import seaborn as sns
#import plotly.express as px

os.chdir(r'C:\Users\zw894hp\Documents\Rugby\Totals\\')
team_stats = pd.read_csv('Teams_2020.csv')
team_stats = team_stats.drop(columns=['Match_ID','Round'])

team_stats['Passing'] = team_stats['Passes'] + team_stats['Offloads']
team_stats['Mauls and Rucks'] = team_stats['Mauls won'] + team_stats['Rucks won']
team_stats['Set Piece'] = team_stats['Scrums won'] + team_stats['Lineout Throw Won']
#team_stats[''] = team_stats[''] + team_stats['']
#team_stats[''] = team_stats[''] + team_stats['']
#team_stats[''] = team_stats[''] + team_stats['']

game_bels = [
        'Team',
        'Possession',
        'Territory',
        'Runs',
        'Kicks in play',
        'Passing',
        'Tackles',
        'Turnovers won',
        'Set Piece',
        'Mauls and Rucks',
        ]

grph_stats = team_stats[team_stats['Team'] == 'CRU'][game_bels]

fig, ax = plt.subplots()
ax.grid(linestyle = ':', axis = 'y')
plt.boxplot((
            grph_stats[grph_stats.columns[1]],
            grph_stats[grph_stats.columns[2]],
            grph_stats[grph_stats.columns[3]],  
            grph_stats[grph_stats.columns[4]],
            grph_stats[grph_stats.columns[5]],
            grph_stats[grph_stats.columns[6]],
            grph_stats[grph_stats.columns[7]],
            grph_stats[grph_stats.columns[8]],
            grph_stats[grph_stats.columns[9]]
            ),
            patch_artist  = True,
            labels = [textwrap.fill(label, 10) for label in game_bels[1:]]
            , widths = 0.6
            )
plt.xlabel('Crusaders')
plt.show()




dis_bels = [
        'Team',
        'Missed Tackles',
        'Turnovers Conceded',
        'Penalties Conceded',
        'Scrums Lost',
        'Rucks Lost',
        'Lineouts Lost'
        ]

t1_stats = team_stats[team_stats['Team'] == 'CRU'][dis_bels]
t2_stats = team_stats[team_stats['Team'] == 'BLU'][dis_bels]

fig, ax = plt.subplots()
ax.grid(linestyle = ':', axis = 'y')
box = plt.boxplot((
            t1_stats[grph_stats.columns[1]],
            t1_stats[grph_stats.columns[2]],
            t1_stats[grph_stats.columns[3]],  
            t1_stats[grph_stats.columns[4]],
            t1_stats[grph_stats.columns[5]],
            t1_stats[grph_stats.columns[6]]
            ),
            patch_artist  = True,
            labels = [textwrap.fill(label, 10) for label in dis_bels[1:]]
            , widths = 0.6
            )
#plt.xlabel('Crusaders')
colors = ['red','red','red','red','red','red']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)

box = plt.boxplot((
            t2_stats[grph_stats.columns[1]],
            t2_stats[grph_stats.columns[2]],
            t2_stats[grph_stats.columns[3]],  
            t2_stats[grph_stats.columns[4]],
            t2_stats[grph_stats.columns[5]],
            t2_stats[grph_stats.columns[6]]
            ),
            patch_artist  = True,
            labels = [textwrap.fill(label, 10) for label in dis_bels[1:]]
            , widths = 0.6
            )
colors = ['blue','blue','blue','blue','blue','blue']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)

plt.show()