import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import os

os.chdir(r'C:\Users\zw894hp\Documents\Rugby\Fox\\')
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}

for x in range(1,25):
    
    
    #ATTACK
    time.sleep(2)
    url = 'https://www.foxsports.com.au/rugby/super-rugby/stats/players?category=kicking&pageNumber=' + str(x)
    
    page = requests.get(url, headers = headers)
    soup = BeautifulSoup(page.content, features = 'lxml')
  
    titles = ['Player','Team']
    for x in soup.find_all('dd'):
        titles.append(x.text)
    
    names = [] 
    for x in soup.find_all('span',class_="fiso-lab-table__row-heading-primary-data"):
        names.append(x.get('title'))
    
    team = [] 
    for x in soup.find_all('span',class_="fiso-lab-table__row-heading-secondary-data"):
        team.append(x.get('title'))
    
    col1  = []
    for i in soup.find_all('td', class_="fiso-lab-table__sorted-column"):
        col1.append(i.text)    
    
    c = 1
    cols = []
    for x in soup.find_all('td',class_=""):
        if c > 52:
            cols.append(x.text)
        c += 1        
    
    c = 0
    p = 0
    t_len = len(titles) - 3
    final = []
    stg = []
    for i in cols:    
        if c < t_len:
            if c == 0:
                stg.append(names[p])
                stg.append(team[p])
                stg.append(col1[p])
                p += 1
                stg.append(i)
                c += 1
            else:
                stg.append(i)
                c += 1  
        if c == t_len:
            final.append(stg)
            c = 0
            stg = []  
    
    stg_df = pd.DataFrame(final, columns=titles)
    
    if 'kicking_df' not in locals():
        kicking_df = stg_df
    else:
        kicking_df = kicking_df.append(stg_df, sort = False)

kicking_df.to_csv('Players_Defence.csv',index=False)