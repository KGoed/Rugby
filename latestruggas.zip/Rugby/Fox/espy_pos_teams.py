import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import os

os.chdir(r'C:\Users\zw894hp\Documents\Rugby\Fox\\')
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}

url_start = 'https://www.espn.co.uk/rugby/matchstats?gameId='
#295371
url_end = '&league=242041'

cols = ['Team','Possession','Territory']

for x in range(295365,295421):
    time.sleep(1)
    #x = 295382
    print('Page: ' + str(x))
    page = requests.get(url_start+str(x)+url_end, headers = headers)
    if page.status_code == 200:
        soup = BeautifulSoup(page.content, 'html.parser')
        t1 = []
        t2 = []
        z = 1
        for y in soup.find_all('span', class_='short-name'):
            team = y.text
            team = team.replace('Melbourne ','')
            team = team.replace('New South Wales ','')
            team = team.replace('Queensland ','')      
            if z == 1:
                t1.append(team)
                z += 1
            else:
                t2.append(team)
        
        z = 1
        for y in soup.find_all('span', class_='chartValue'):
            if '%' in y.text:
                if z == 1:
                    t1.append(int(y.text.replace('%','')))
                    z += 1
                else:
                    t2.append(int(y.text.replace('%','')))
                    z = 1   
        
        teams = []
        teams.append(t1)
        teams.append(t2)
        stg = pd.DataFrame(teams, columns = cols)
        stg['Game'] = t1[0] + 'v' + t2[0]
    
        if 'final' not in locals():
            final = stg
        else:
            final = final.append(stg, sort = False)
            
final = final[final.Possession != 0]
final = final.reset_index(drop = True)

final.to_csv('Teams_Pos_Ter.csv',index=False)