import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import os

os.chdir(r'C:\Users\zw894hp\Documents\Rugby\Fox\\')
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}
url_stg = 'https://www.foxsports.com.au/rugby/super-rugby/stats/'

  
#GET GAMES PLAYED



#GET TERRITORY AND POSSESION?



#CHECK THIS BEFORE RUNNING!!! NOT SURE HOW, FIGURE OUT A TEST
score_board = 16

#Summary
time.sleep(2)
f_type = 'teams'
url = url_stg + f_type 
page = requests.get(url, headers = headers)
soup = BeautifulSoup(page.content, features = 'lxml')
  
titles = ['Team']
for x in soup.find_all('dd'):
    titles.append(x.text)

names = [] 
for x in soup.find_all('span',class_="fiso-lab-table__row-heading-primary-data"):
    names.append(x.get('title'))

col1  = []
for i in soup.find_all('td', class_="fiso-lab-table__sorted-column"):
    col1.append(i.text)    

c = 1
cols = []
for x in soup.find_all('td',class_=""):
    if c > score_board:
        cols.append(x.text)
    c += 1            

c = 0
p = 0
t_len = len(titles) - 2
final = []
stg = []
for i in cols:    
    if c < t_len:
        if c == 0:
            stg.append(names[p])
            stg.append(col1[p])
            p += 1
            stg.append(i)
            c += 1
        else:
            stg.append(i)
            c += 1  
    if c == t_len:
        final.append(stg)
        c = 0
        stg = []  

stg_df = pd.DataFrame(final, columns=titles)

if 'summary_df' not in locals():
    summary_df = stg_df
else:
    summary_df = summary_df.append(stg_df, sort = False)

#Attack
time.sleep(2)
f_type = 'attack'
url = url_stg + 'teams?category=' 

page = requests.get(url, headers = headers)
soup = BeautifulSoup(page.content, features = 'lxml')
  
titles = ['Team']
for x in soup.find_all('dd'):
    titles.append(x.text)

names = [] 
for x in soup.find_all('span',class_="fiso-lab-table__row-heading-primary-data"):
    names.append(x.get('title'))

col1  = []
for i in soup.find_all('td', class_="fiso-lab-table__sorted-column"):
    col1.append(i.text)    

c = 1
cols = []
for x in soup.find_all('td',class_=""):
    if c > score_board:
        cols.append(x.text)
    c += 1        

c = 0
p = 0
t_len = len(titles) - 2
final = []
stg = []
for i in cols:    
    if c < t_len:
        if c == 0:
            stg.append(names[p])
            stg.append(col1[p])
            p += 1
            stg.append(i)
            c += 1
        else:
            stg.append(i)
            c += 1  
    if c == t_len:
        final.append(stg)
        c = 0
        stg = []  

stg_df = pd.DataFrame(final, columns=titles)

if 'attack_df' not in locals():
    attack_df = stg_df
else:
    attack_df = attack_df.append(stg_df, sort = False)


#DEFENCE
time.sleep(2)
f_type = 'defenceAndDiscipline'
url = url_stg + 'teams?category=' + f_type

page = requests.get(url, headers = headers)
soup = BeautifulSoup(page.content, features = 'lxml')
  
titles = ['Team']
for x in soup.find_all('dd'):
    titles.append(x.text)

names = [] 
for x in soup.find_all('span',class_="fiso-lab-table__row-heading-primary-data"):
    names.append(x.get('title'))

team = [] 
for x in soup.find_all('span',class_="fiso-lab-table__row-heading-secondary-data"):
    team.append(x.get('title'))

col1  = []
for i in soup.find_all('td', class_="fiso-lab-table__sorted-column"):
    col1.append(i.text)    

c = 1
cols = []
for x in soup.find_all('td',class_=""):
    if c > score_board:
        cols.append(x.text)
    c += 1        

c = 0
p = 0
t_len = len(titles) - 2
final = []
stg = []
for i in cols:    
    if c < t_len:
        if c == 0:
            stg.append(names[p])
            stg.append(col1[p])
            p += 1
            stg.append(i)
            c += 1
        else:
            stg.append(i)
            c += 1  
    if c == t_len:
        final.append(stg)
        c = 0
        stg = []  

stg_df = pd.DataFrame(final, columns=titles)

if 'defence_df' not in locals():
    defence_df = stg_df
else:
    defence_df = defence_df.append(stg_df, sort = False)

#KICKING
time.sleep(2)
f_type = 'kicking'
url = url_stg + 'teams?category=' + f_type

page = requests.get(url, headers = headers)
soup = BeautifulSoup(page.content, features = 'lxml')
  
titles = ['Team']
for x in soup.find_all('dd'):
    titles.append(x.text)

names = [] 
for x in soup.find_all('span',class_="fiso-lab-table__row-heading-primary-data"):
    names.append(x.get('title'))

team = [] 
for x in soup.find_all('span',class_="fiso-lab-table__row-heading-secondary-data"):
    team.append(x.get('title'))

col1  = []
for i in soup.find_all('td', class_="fiso-lab-table__sorted-column"):
    col1.append(i.text)    

c = 1
cols = []
for x in soup.find_all('td',class_=""):
    if c > score_board:
        cols.append(x.text)
    c += 1        

c = 0
p = 0
t_len = len(titles) - 2
final = []
stg = []
for i in cols:    
    if c < t_len:
        if c == 0:
            stg.append(names[p])
            stg.append(col1[p])
            p += 1
            stg.append(i)
            c += 1
        else:
            stg.append(i)
            c += 1  
    if c == t_len:
        final.append(stg)
        c = 0
        stg = []  

stg_df = pd.DataFrame(final, columns=titles)

if 'kicking_df' not in locals():
    kicking_df = stg_df
else:
    kicking_df = kicking_df.append(stg_df, sort = False)


#Merge?
#all_player_stats = pd.merge(summary_df,attack_df,
#                            on=['Player','Team','Games','Tries','Points',
#                                'Runs','Run Metres','Linebreaks','Tackle Busts',
#                                'Offloads','Kicks','Kick Metres'],
#                            how = 'inner')

#all_player_stats = pd.merge(all_player_stats,defence_df
#                            ,on=['Player','Team','Games','Turnovers','Handling Errors',
#                                 'Penalties Conceded','Yellow Cards','Red Cards','Tackles',
#                                 'Missed Tackles','Pilfers'],
#                            how = 'inner')

#all_player_stats = pd.merge(all_player_stats,kicking_df
#                            ,on=['Player','Team','Games','Conversions','Penalty Goals','Drop Goals','Points',
#                                 'Kicks','Kick Metres','Kick Errors'],
#                            how = 'inner')

summary_df.to_csv('Teams_All_Stats.csv',index=False)

#summary_df.to_csv('Players_Summary.csv',index=False)
#attack_df.to_csv('Players_Attack.csv',index=False)
#defence_df.to_csv('Players_Defence.csv',index=False)
#kicking_df.to_csv('Players_Kicking.csv',index=False)