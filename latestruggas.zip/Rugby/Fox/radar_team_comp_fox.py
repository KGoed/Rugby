import os
import pandas as pd
import matplotlib.pyplot as plt
from math import pi
import textwrap

matches = (('HUR','BLU'),('REB','LIO'),('SHA','JAG')
            ,('BUL','HIG'))

#matches = (('SUN','BRU'),('CRU','RED'),('WAR','CHF'),('HUR','BLU'),('REB','LIO'),('SHA','JAG'),('BUL','HIG'))


col_list = {'BLU':'blue',
            'BRU':'gold',
            'BUL':'blue',
            #'BUL':'cornflowerblue',
            'CHF':'darkgoldenrod',
            'CRU':'darkred',
            'HIG':'green',
            #'HUR':'midnightblue',
            'HUR':'darkgoldenrod',
            'JAG':'orange',
            'LIO':'firebrick',
            #'REB':'navy',
            'REB':'blue',
            'RED':'firebrick',
            'SHA':'black',
            'STO':'midnightblue',
            'SUN':'firebrick',
            'WAR':'cornflowerblue'
            }

map_list = {'Blues':'BLU',
            'Brumbies':'BRU',
            'Bulls':'BUL',
            'Chiefs':'CHF',
            'Crusaders':'CRU',
            'Highlanders':'HIG',
            'Hurricanes':'HUR',
            'Jaguares':'JAG',
            'Lions':'LIO',
            'Rebels':'REB',
            'Reds':'RED',
            'Sharks':'SHA',
            'Stormers':'STO',
            'Sunwolves':'SUN',
            'Waratahs':'WAR'
            }

os.chdir(r'C:\Users\zw894hp\Documents\Rugby\Fox\\')

pos_stats = pd.read_csv('Teams_Pos_Ter.csv')
pos_stats = pos_stats.drop('Game', axis = 1)
pos_stats = pos_stats.groupby('Team',as_index = False).mean()

#pos_stats = pos_stats.groupby('Team',as_index = False).sum()
pos_stats['Team'] = pos_stats['Team'].map(map_list)
pos_stats.rename(columns={'Possession':'Possession %'}, inplace=True)
pos_stats.rename(columns={'Territory':'Territory %'}, inplace=True)

player_stats = pd.read_csv('Players_All_Stats.csv')
p_stats_req = ['Team','Runs','Possessions','Pilfers','Passes','Kick Errors']
player_stats = player_stats[p_stats_req]
player_stats = player_stats.groupby('Team', as_index = False).sum()

team_stats = pd.read_csv('Teams_All_Stats.csv')
team_stats = pd.merge(team_stats,player_stats, on = 'Team')

team_stats['Team'] = team_stats['Team'].map(map_list)
team_stats = pd.merge(team_stats,pos_stats, on = 'Team')

team_stats.rename(columns={'Pilfers':'Steals'}, inplace=True)
team_stats.rename(columns={'Tight Head Wins':'Opp Scrum Wins'}, inplace=True)
team_stats['Penalties & Free Kicks Conceded'] = team_stats['Penalties Conceded'] + team_stats['Free Kicks Conceded']

#team_stats['Run Metres'] =  team_stats['Run Metres'].apply(lambda x : x.replace(',',''))
#team_stats['Kick Metres'] =  team_stats['Kick Metres'].apply(lambda x : x.replace(',',''))
#team_stats['Run Metres Conceded'] =  team_stats['Run Metres Conceded'].apply(lambda x : x.replace(',',''))
#team_stats['Run Metres'] = pd.to_numeric(team_stats['Run Metres'])
#team_stats['Kick Metres'] = pd.to_numeric(team_stats['Kick Metres'])
#team_stats['Run Metres Conceded'] = pd.to_numeric(team_stats['Run Metres Conceded'])
#staging['Lineouts'] = staging['Lineout Throw Won Clean'] + staging['Lineout Won Steal']
#staging['Carries Metres'] = staging['Carries Metres'] / 10
#team_stats.rename(columns={'Carries Metres':'Carry Metres'}, inplace=True)


for c in team_stats.columns:
    if c not in ['Team','Games']:
        if '%' not in c:
            team_stats[c] = round(team_stats[c] / team_stats['Games'],1)

team_stats.rename(columns={'Possession %':'Possession'}, inplace=True)
team_stats.rename(columns={'Territory %':'Territory'}, inplace=True)
team_stats.rename(columns={'Advantage Line %':'Advantage Line Gains'}, inplace=True)



grps = ['attack','defence','sp']

attack = ['Team'
         ,'Possession','Territory'
         ,'Advantage Line Gains','Phases 7+'
         ,'Passes','Offloads','Kicks','Pick & Drives'
         ,'Run Metres','Kick Metres'
         ,'Linebreaks','Tackle Busts'
         ]

defence = ['Team',
           'Tackles','Missed Tackles',
           'Run Metres Conceded','Advantage Line % Conceded',
           'Linebreaks Conceded','Ruck & Maul Penalties Forced',
           'Turnovers','Steals'
           ]

sp = ['Team',
    'Penalties Awarded',
    'Penalties & Free Kicks Conceded',
    'Handling Errors',
    'Kick Errors',
    'Scrum Feed Win %',
    'Opp Scrum Wins',
    'Own Lineout Win %',
    'Opp Lineout Wins']

for y in matches:
    
    t1 = y[0]
    t2 = y[1]
      
    for x in grps:
        
        if x == 'attack':
            main_stats = team_stats[attack]
        elif x == 'defence':
            main_stats = team_stats[defence]
        elif x == 'sp':
            main_stats = team_stats[sp]
            
        t1_stats = main_stats[main_stats['Team'] == t1] 
        t2_stats = main_stats[main_stats['Team'] == t2] 
        
        grph_stats = t1_stats.append(t2_stats)
        grph_stats = grph_stats.reset_index(drop=True)
        
        for c in grph_stats.columns:
            if c not in ['Team']:
                total = grph_stats[c].sum(axis=0)
                grph_stats[c].loc[0] =   round(grph_stats[c].loc[0] / total * 100,0)
                grph_stats[c].loc[1] =   round(grph_stats[c].loc[1] / total * 100,0)
            
        categories=list(grph_stats)[1:]
        N = len(categories)
        angles = [n / float(N) * 2 * pi for n in range(N)]
        angles += angles[:1]
        
        ax = plt.subplot(111, polar=True)
        ax.set_theta_offset(pi / 2)
        ax.set_theta_direction(-1)
        
        plt.xticks(angles[:-1], [textwrap.fill(label,10) for label in categories])
        ax.tick_params(axis ='x', which = 'both', direction = 'out', pad = 7) 
        ax.set_rlabel_position(0)
        plt.yticks([10,20,30,40,50,60,70,80,90], ['','','','','','','','',''],color="grey", size=7)
        plt.ylim(0,80)  
        
        for i in range(0,len(grph_stats)):
            tm = grph_stats.iloc[i]['Team']
            values= grph_stats.loc[i].drop(['Team']).values.flatten().tolist()
            values += values[:1]
            ax.plot(angles, values, linewidth=1, linestyle='solid', label=tm, color = col_list[tm])
            ax.fill(angles, values, 'b', alpha=0.1, color = col_list[tm])
        
        plt.legend(loc='upper right', bbox_to_anchor=(0.0, 0.1))
        save_string = t1 + '_' + t2 + '_' + x + '.png'
        plt.savefig(save_string, bbox_inches='tight')
        plt.show()