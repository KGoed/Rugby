import os
import pandas as pd
import matplotlib.pyplot as plt
from math import pi

#Import stats
os.chdir('C:\\Users\\zw894hp\\Documents\Rugby\\')
links = pd.read_csv('Links_2019.csv')
matches = pd.read_csv('Team_Stats_2019.csv')
players_stats = pd.read_csv('Player_Stats_2019_Cleaned.csv')
players = pd.read_csv('Players_2019.csv')
players_stats['game_count'] = 1

full_stats = players_stats.drop(['Number','Team','Venue','Match_ID'], axis = 1)
full_stats = full_stats.groupby('Player',as_index=False).sum()

ply_team = players.set_index('Player')['Team'].to_dict()
col_list = {'BLU':'blue',
            'BRU':'gold',
            'BUL':'cornflowerblue',
            'CHI':'darkgoldenrod',
            'CRU':'darkred',
            'HIG':'green',
            'HUR':'yellow',
            'JAG':'orange',
            'LIO':'red',
            'REB':'navy',
            'RED':'firebrick',
            'SHA':'black',
            'STO':'midnightblue',
            'SUN':'lightsalmon',
            'WAR':'cyan'
            }


#Set up values
stats_required = ['Runs','Passes','Kicks from Hand']






flys = players_stats[players_stats['Number'] == 10].groupby('Player',as_index=False)[['Runs','Passes','Kicks From Hand','game_count']].sum()
flys = pd.merge(flys,players,on='Player')

flys['Runs'] = round(flys['Runs'] / flys['game_count'],1)
flys['Passes'] = round(flys['Passes'] / flys['game_count'],1)
flys['Kicks From Hand'] = round(flys['Kicks From Hand'] / flys['game_count'],1)

ply_team = flys.set_index('Player')['Team'].to_dict()
#my_list = ['Elton Jantjies','Handre Pollard','Jean-Luc du Plessis','Robert du Preez']

sa_flys = flys[flys['Country']=='SA'][['Player','Runs','Passes','Kicks From Hand']]
sa_flys = sa_flys.reset_index(drop = True)


my_list = ['Elton Jantjies','Handre Pollard','Robert du Preez','Damian Willemse']
my_flys = sa_flys[sa_flys['Player'].isin(my_list)]
my_flys = my_flys.reset_index(drop=True)


# number of variable
categories=list(my_flys)[1:]
N = len(categories)
 
# What will be the angle of each axis in the plot? (we divide the plot / number of variable)
angles = [n / float(N) * 2 * pi for n in range(N)]
angles += angles[:1]
 
# Initialise the spider plot
ax = plt.subplot(111, polar=True)
 
# If you want the first axis to be on top:
ax.set_theta_offset(pi / 2)
ax.set_theta_direction(-1)
 
# Draw one axe per variable + add labels labels yet
plt.xticks(angles[:-1], categories)
 
# Draw ylabels
ax.set_rlabel_position(0)
plt.yticks([5,10,15,20,25], ['5','10','15','20','25'], color="grey", size=7)
plt.ylim(0,25)

for i in range(0,len(my_flys)):
    plyr = my_flys.iloc[i]['Player']
    values=my_flys.loc[i].drop('Player').values.flatten().tolist()
    values += values[:1]
    ax.plot(angles, values, linewidth=1, linestyle='solid', label=plyr, color = col_list[ply_team[plyr]])
    ax.fill(angles, values, 'b', alpha=0.1)
plt.legend(loc='upper right', bbox_to_anchor=(0.1, 0.1))


